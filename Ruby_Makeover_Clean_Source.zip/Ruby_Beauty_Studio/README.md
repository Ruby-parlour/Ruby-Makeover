# Ruby Beauty Studio

A Beauty Parlour Management System built with Python, Django, HTML, CSS and SQLite.

## Run locally

1. Install Python.
2. Open a terminal in this folder.
3. Install dependencies: `pip install -r requirements.txt`
4. Create the local database: `python manage.py migrate`
5. Start the server: `python manage.py runserver`
6. Open http://127.0.0.1:8000/ in your browser.

The SQLite database is not included. Django will create a fresh local database when migrations are run. Create your own admin account with `python manage.py createsuperuser` if needed.
