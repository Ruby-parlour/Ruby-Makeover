
from django.contrib import admin
from .models import Register, Appointment, Payment, AppointmentNotification

admin.site.register(Register)
admin.site.register(Appointment)
admin.site.register(Payment)


@admin.register(AppointmentNotification)
class AppointmentNotificationAdmin(admin.ModelAdmin):
    list_display = (
        'appointment',
        'days_before',
        'is_read',
        'created_at',
    )
    list_filter = ('days_before', 'is_read')
