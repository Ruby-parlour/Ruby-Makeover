from django.urls import path
from . import views


urlpatterns=[

    path('',views.home,name="home"),

    path('login/',views.login,name="login"),
    path('register/', views.register, name='register'),
    path('products/', views.products, name='products'),
    path('services/', views.services, name='services'),
    path('appointment/', views.appointment, name='appointment'),
    path('payment/', views.payment, name='payment'),
    path('contact/', views.contact, name='contact'),
    path('about/', views.about, name='about'),
    path('reviews/', views.reviews, name='reviews'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
   
    path("cart/", views.cart, name="cart"),
    path("order/", views.order, name="order"),

]