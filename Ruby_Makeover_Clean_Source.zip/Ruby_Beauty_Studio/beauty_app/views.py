from django.shortcuts import render, redirect
from .models import Register, Appointment, Payment


def home(request):
    return render(request, "home.html")


def login(request):
    if request.method == "POST":

        username = request.POST["username"]
        password = request.POST["password"]

        try:
            user = Register.objects.get(
                username=username,
                password=password
            )

            return redirect("/")

        except Register.DoesNotExist:

            return render(request, "login.html", {
                "error": "Invalid Username or Password"
            })

    return render(request, "login.html")


def register(request):
    if request.method == "POST":

        fullname = request.POST["fullname"]
        email = request.POST["email"]
        mobile = request.POST["mobile"]
        username = request.POST["username"]
        password = request.POST["password"]

        Register.objects.create(
            fullname=fullname,
            email=email,
            mobile=mobile,
            username=username,
            password=password
        )

        return redirect("/login/")

    return render(request, "register.html")


def products(request):
    return render(request, "products.html")


def services(request):
    return render(request, "services.html")


def appointment(request):

    if request.method == "POST":

        name = request.POST["name"]
        phone = request.POST["phone"]
        service = request.POST["service"]
        date = request.POST["date"]
        time = request.POST["time"]

        Appointment.objects.create(
            name=name,
            phone=phone,
            service=service,
            date=date,
            time=time
        )

        return redirect("/payment/")

    return render(request, "appointment.html")


def payment(request):

    if request.method == "POST":

        customer_name = request.POST["customer_name"]
        payment_method = request.POST["payment_method"]
        amount = request.POST["amount"]

        Payment.objects.create(
            customer_name=customer_name,
            payment_method=payment_method,
            amount=amount
        )

        return redirect("/order/")

    return render(request, "payment.html")


def contact(request):
    return render(request, "contact.html")


def about(request):
    return render(request, "about.html")


def reviews(request):
    return render(request, "reviews.html")


def admin_dashboard(request):
    return render(request, "admin_dashboard.html")


def cart(request):
    return render(request, "cart.html")


def order(request):
    return render(request, "order.html")